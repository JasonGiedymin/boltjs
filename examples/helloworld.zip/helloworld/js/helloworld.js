var core  = require('javelin/core');
var View  = require('view').View;

var HelloView = core.createClass({
  extend: View,

  declare: function(options) {
    return{
      content: "Hello World!"
    }
  }
})

exports.init = function() {
  var helloView;
  helloView = new HelloView();
  helloView.placeIn(document.body);
}
